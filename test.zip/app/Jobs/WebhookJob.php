<?php

namespace App\Jobs;

use Spatie\WebhookClient\Jobs\ProcessWebhookJob as ProcessWebhookJob;

class WebhookJob extends ProcessWebhookJob
{

    public function handle(): void
    {
        logger('Пришел вебхук');
        logger($this->webhookCall);
    }
}
